package com.backend.sugarlab.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.backend.sugarlab.entity.Assinatura;

public interface AssinaturaRepository extends JpaRepository<Assinatura, Integer> {
}
