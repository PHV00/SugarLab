package com.backend.sugarlab.service;

import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.backend.sugarlab.DTO.LoginRequestDTO;
import com.backend.sugarlab.DTO.LoginResponseDTO;
import com.backend.sugarlab.entity.Usuario;
import com.backend.sugarlab.repository.UserRespository;
import com.backend.sugarlab.security.JwtUtil;

@Service
public class LoginService {

    private final UserRespository userRespository;
    private final PasswordEncoder passwordEncoder;
    private final JwtUtil jwtUtil;

    public LoginService(UserRespository userRespository, PasswordEncoder passwordEncoder, JwtUtil jwtUtil){
        this.userRespository = userRespository;
        this.passwordEncoder = passwordEncoder;
        this.jwtUtil = jwtUtil;
    }

    public LoginResponseDTO login(LoginRequestDTO loginRequest) {
        // Buscar usuário pelo email
        Usuario usuario = userRespository.findByEmail(loginRequest.getEmail())
                                .orElseThrow(() -> new RuntimeException("Usuário não encontrado"));

        // Verificar senha
        if (!passwordEncoder.matches(loginRequest.getSenha(), usuario.getSenha())) {
            throw new RuntimeException("Senha incorreta");
        }

        // Gerar token JWT com as informações do usuário
        String token = jwtUtil.generateToken(usuario);

        // Criar DTO de resposta
        LoginResponseDTO response = new LoginResponseDTO();
        response.setToken(token);
        response.setEmail(usuario.getEmail());
        response.setNome(usuario.getNome());
        response.setEhAdmin(usuario.getEhAdmin() != null && usuario.getEhAdmin()); // trata null

        return response;
    }
}