package com.backend.sugarlab.enums;

public enum Status {
    Rascunho,
    Publicado
}
