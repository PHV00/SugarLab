package com.backend.sugarlab.DTO;

import java.util.Set;

public record ReceitaDTO(String titulo, Set<Integer> alimentos) {}
