package com.backend.sugarlab.DTO;

public record EventoDTO(String nome, String descricao, String localizacao) {}
